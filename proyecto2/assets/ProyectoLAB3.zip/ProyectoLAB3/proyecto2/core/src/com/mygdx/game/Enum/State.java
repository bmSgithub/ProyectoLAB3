package com.mygdx.game.Enum;

public enum State {
    FALLING, JUMPING, STANDING,RUNNING;
}
